//package bpTest;


import static org.junit.Assert.assertEquals;

//import bubble.BubbleSort;

//import bubble.BubbleSort;
import java.util.Arrays;

import org.junit.After;
import org.junit.Before;
//import backPack.BackPack;
import org.junit.Test;
public class bpTest {
	private BackPack b;
	int m =  10;
    int n =3;
	int w[] = {3, 4, 5};
    int p[] = {4, 5, 6};

    int c[][] = {{0},{0,0,0,4,4,4,4,4,4,4,4},{0,0,0,4,5,5,5,9,9,9,9},{0,0,0,4,5,6,6,9,10,11,11}};
			
	@Before
	public void setup() throws Exception{
		b = new BackPack();
	}
	
	@After 
	public void down() throws Exception{
		b = null;
	}
	@Test
	public void SortTest() {
		for(int i =1;i<=n;i++) {
			for(int j =1;j<=m;j++) {
				assertEquals(c[i][j],BackPack.BackPack_Solution(m,n,w,p)[i][j]);
			}
		}
		
	}
}
